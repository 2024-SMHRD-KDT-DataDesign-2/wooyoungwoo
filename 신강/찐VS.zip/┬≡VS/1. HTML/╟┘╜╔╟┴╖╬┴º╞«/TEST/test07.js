// 메뉴 버튼 클릭 시 작동하는 함수
let navBtn1 = document.getElementById('button1');

navBtn1.addEventListener('click', function() {
    if (navBtn1.classList.contains('open')) {
        navBtn1.classList.toggle('open');
        document.getElementById('menu').style.display = 'none';
    } else {
        navBtn1.classList.toggle('open');
        document.getElementById('menu').style.display = 'grid';
    }
});

// 스크롤 시 back-to-top 버튼의 투명도 조절
window.addEventListener('scroll', function() {
    let scroll = window.pageYOffset;
    let backToTop = document.querySelector(".back-to-top a");

    if (scroll <= 250) {
        backToTop.style.opacity = "0";
    } else {
        backToTop.style.opacity = "1";
    }
});

// 앵커 태그 클릭 시 스크롤 애니메이션
document.querySelectorAll('a[href*="#"]')
    .forEach(function(anchor) {
        if (!anchor.getAttribute('href').match(/(^#$|^#0$)/)) {
            anchor.addEventListener('click', function(event) {
                let target = document.querySelector(this.hash) || document.querySelector(`[name='${this.hash.slice(1)}']`);
                
                if (target) {
                    event.preventDefault();
                    window.scroll({
                        top: target.offsetTop,
                        behavior: 'smooth'
                    });

                    target.focus({ preventScroll: true });
                    if (!target.isSameNode(document.activeElement)) {
                        target.setAttribute('tabindex', '-1');
                        target.focus();
                    }
                }
            });
        }
    });

// 마우스 오버 시 verified 텍스트 보이기/숨기기
let usernameWrapper = document.querySelector(".username-wrapper");

usernameWrapper.addEventListener('mouseenter', function() {
    let verified = document.querySelector(".verified");
    verified.style.opacity = "1";
    verified.style.top = "130%";
});

usernameWrapper.addEventListener('mouseleave', function() {
    let verified = document.querySelector(".verified");
    verified.style.opacity = "0";
    verified.style.top = "150%";
});

// 버튼 클릭 시 작동하는 함수 (showContent)
function showContent(sectionId) {
    // 모든 섹션을 숨김
    var sections = document.querySelectorAll('.content-section');
    sections.forEach(function(section) {
        section.style.display = 'none';
    });

    // 클릭한 섹션만 표시
    var selectedSection = document.getElementById(sectionId);
    selectedSection.style.display = 'block';
}

// 각 버튼에 이벤트 리스너 추가
document.getElementById('ufo-home').addEventListener('click', function() {
    showContent('content-trophies');
});

document.getElementById('ufo-videos').addEventListener('click', function() {
    showContent('content-points');
});

document.getElementById('ufo-images').addEventListener('click', function() {
    showContent('content-posts');
});

document.getElementById('ufo-about').addEventListener('click', function() {
    showContent('content-about');
});

// 탭 메뉴 관련 이벤트
document.getElementById('trophies-tab').addEventListener('click', function() {
    showTab('trophies');
});

document.getElementById('points-tab').addEventListener('click', function() {
    showTab('points');
});

document.getElementById('posts-tab').addEventListener('click', function() {
    showTab('posts');
});

document.getElementById('about-tab').addEventListener('click', function() {
    showTab('about');
});

function showTab(tab) {
    // 모든 섹션 숨기기
    document.getElementById('trophies-content').style.display = 'none';
    document.getElementById('points-content').style.display = 'none';
    document.getElementById('posts-content').style.display = 'none';
    document.getElementById('about-content').style.display = 'none';

    // 모든 버튼에서 active 클래스 제거
    document.getElementById('trophies-tab').classList.remove('active');
    document.getElementById('points-tab').classList.remove('active');
    document.getElementById('posts-tab').classList.remove('active');
    document.getElementById('about-tab').classList.remove('active');

    // 선택한 섹션 표시 및 클릭한 버튼에 active 클래스 추가
    document.getElementById(`${tab}-content`).style.display = 'block';
    document.getElementById(`${tab}-tab`).classList.add('active');
}

// 프로필 사진 클릭 시 파일 선택 창 열기
document.getElementById('profile-pic').addEventListener('click', function() {
    document.getElementById('upload-profile-pic').click();
});

// 파일 선택 후 미리보기 이미지 변경
document.getElementById('upload-profile-pic').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('profile-pic').src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});
