console.log('JS Connect!');

// Step1. moveLeft라는 함수를 선언
// 1-1) id가 horse인 태그를 js로 가져온다
// 1-2) moveLeft 함수가 호출 될 때 마다
//        말을 왼쪽으로 50px씩 이동시키기
//  단, 말이 배경을 벗어나지 않도록 하자
let move = 0;

const moveLeft = () => {
    console.log('left func');
    let horse = document.getElementById('horse')
    if (move < 1200) {
        move += 50;
        horse.style.right = move + 'px';
    }



}

// Step2. moveRight 함수 선ㅅ언
// 2-1) id가 horse인 태그를 js로 가져온다.
// 2-2) moveRight 함수를 호출될때마다
//      말을 오른쪽으로  50px씩 이동시키기
//  단, 말이 배경을 벗어나지 않도록 하자
const moveRight = () => {
    if (move > 0) {


        move -= 50;
        document.getElementById('horse').style.
            right = move + 'px';
    }
}


// 주의할 점! btn left는 하나의 클래스이름이 아니다.
// btn 이라는 클래스 left 클래스 둘 다 포함 !

// Step3. left 버튼을 클릭하면 moveleft 함수를 호출
let btn = document.getElementsByClassName('btn');
console.log(btn);
btn[0].addEventListener('click', moveLeft);




// Step4. right 버튼을 클릭하면 moveright 함수를 호출
btn[1].addEventListener('click', moveRight);