console.log('외부에서 작성된 코드입니다.');
