window.addEventListener('click', (event) => {
    let button = event.target;
    if (document.documentElement.contains(event.target)) {
        do {
            if (button.matches('.toggle-button[data-toggle-target-selector]')) {
                event.preventDefault();
                let target = document.querySelector(button.getAttribute('data-toggle-target-selector'));
                if (target) {
                    if (target.classList.contains('toggle-target-active')) {
                        button.classList.remove('toggle-button-active');
                        target.classList.remove('toggle-target-active');
                    } else {
                        button.classList.add('toggle-button-active');
                        target.classList.add('toggle-target-active');
                    }
                }
            }
            button = button.parentElement;
        } while (button !== null);
    }
});

// 새로운 대화방 추가하는 동작 처리 코드
window.addEventListener('DOMContentLoaded', () => {
    const newChatButton = document.getElementById('newChatButton');

    if (newChatButton) {
        newChatButton.addEventListener('click', function(event) {
            event.preventDefault();

            // 대화 목록을 가져옴
            const conversationList = document.querySelector('.conversations-list-items');

            // 새로운 대화방 HTML 생성
            const newConversationHTML = `
            <div class="conversations-list-item single">
                <a href="#!" class="image">
                    <img src="https://cdn.iconscout.com/icon/free/png-256/avatar-372-456324.png" />
                </a>
                <a href="#!" class="name">New Chat</a>
                <a href="#!" class="message">You: Hello, let's start a new chat!</a>
                <div class="time">Just now</div>
            </div>`;

            // 새로운 대화방을 대화 목록에 추가
            conversationList.insertAdjacentHTML('beforeend', newConversationHTML);
        });
    }
});