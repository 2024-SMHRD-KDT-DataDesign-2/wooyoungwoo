package Controller;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.*;

@ServerEndpoint("/ChattingService")
public class ChattingService {

    private static Map<String, Set<Session>> chatRooms = new HashMap<>();
    private static Set<Session> clients = Collections.synchronizedSet(new HashSet<>());
    private static Map<Session, String> userIds = Collections.synchronizedMap(new HashMap<>());

    @OnOpen
    public void onOpen(Session session) {
        clients.add(session);
        System.out.println("새로운 클라이언트가 연결되었습니다: " + session.getId());
    }

    @OnMessage
    public void onMessage(String message, Session session) throws IOException {
        String[] parts = message.split(":", 2);
        String command = parts[0];

        if (command.equals("CREATE_ROOM")) {
            String roomName = parts[1];
            chatRooms.put(roomName, new HashSet<>());
            System.out.println("채팅방이 생성되었습니다: " + roomName);
        } else if (command.equals("JOIN_ROOM")) {
            String roomName = parts[1];
            chatRooms.get(roomName).add(session);
            userIds.put(session, "User " + session.getId()); // 여기에 사용자 ID 설정
            System.out.println("사용자가 채팅방에 참여했습니다: " + roomName);
        } else {
            // 일반 메시지 처리
            String userId = userIds.get(session);
            if (userId == null) {
                userId = "Unknown";
            }

            for (Map.Entry<String, Set<Session>> entry : chatRooms.entrySet()) {
                String room = entry.getKey();
                Set<Session> sessions = entry.getValue();
                if (sessions.contains(session)) {
                    for (Session client : sessions) {
                        if (client.isOpen() && client != session) {
                            client.getBasicRemote().sendText(userId + ": " + parts[1]);
                        }
                    }
                }
            }
        }
    }

    @OnClose
    public void onClose(Session session) {
        clients.remove(session);
        userIds.remove(session);

        for (Set<Session> sessions : chatRooms.values()) {
            sessions.remove(session);
        }

        System.out.println("클라이언트가 연결을 종료했습니다: " + session.getId());
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        System.out.println("오류 발생: " + throwable.getMessage());
    }
}
