let ws;
let currentRoom = "";

ws = new WebSocket("ws://" + location.host + "/Chatting/ChattingService");

ws.onmessage = function(event) {
	let chatArea = document.getElementById("chatArea");
	chatArea.value += event.data + "\n";
};

ws.onclose = function() {
	alert("Disconnected from server.");
};

function createRoom() {
	let roomName = document.getElementById("roomName").value;
	ws.send("CREATE_ROOM:" + roomName);
	document.getElementById("roomName").value = '';
}

function joinRoom() {
	let roomName = document.getElementById("roomName").value;
	currentRoom = roomName;
	ws.send("JOIN_ROOM:" + roomName);
	document.getElementById("roomName").value = '';
}

function sendMessage() {
	let message = document.getElementById("message").value;
	let chatArea = document.getElementById("chatArea");

	if (currentRoom) {
		chatArea.value += "나 : " + message + "\n";
		ws.send(currentRoom + ":" + message);
	} else {
		alert("Please join a room first.");
	}
	document.getElementById("message").value = '';
}